# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(section-sizes src/section-sizes.cpp)
set_property(TARGET section-sizes PROPERTY CXX_STANDARD 11)
target_link_libraries(section-sizes lionss pthread)

add_executable(clang-format src/clang-format.cpp)
set_property(TARGET clang-format PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-format lionss pthread)

add_executable(cache-bench src/cache-bench.cpp)
set_property(TARGET cache-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(cache-bench lionss pthread)

add_executable(dast-scan src/dast-scan.cpp)
set_property(TARGET dast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dast-scan lionss pthread)

add_executable(docstring-coverage src/docstring-coverage.cpp)
set_property(TARGET docstring-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(docstring-coverage lionss pthread)

add_executable(clang-17 src/clang-17.cpp)
set_property(TARGET clang-17 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-17 lionss pthread)

add_executable(clang-oldest src/clang-oldest.cpp)
set_property(TARGET clang-oldest PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-oldest lionss pthread)

add_executable(cli-tests src/cli-tests.cpp)
set_property(TARGET cli-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(cli-tests lionss pthread)

add_executable(codeblock-run src/codeblock-run.cpp)
set_property(TARGET codeblock-run PROPERTY CXX_STANDARD 11)
target_link_libraries(codeblock-run lionss pthread)

add_executable(secrets-scan src/secrets-scan.cpp)
set_property(TARGET secrets-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(secrets-scan lionss pthread)

add_executable(symbol-count src/symbol-count.cpp)
set_property(TARGET symbol-count PROPERTY CXX_STANDARD 11)
target_link_libraries(symbol-count lionss pthread)

add_executable(valgrind-helgrind src/valgrind-helgrind.cpp)
set_property(TARGET valgrind-helgrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-helgrind lionss pthread)

add_executable(scoop-manifest src/scoop-manifest.cpp)
set_property(TARGET scoop-manifest PROPERTY CXX_STANDARD 11)
target_link_libraries(scoop-manifest lionss pthread)

add_executable(strict-warnings src/strict-warnings.cpp)
set_property(TARGET strict-warnings PROPERTY CXX_STANDARD 11)
target_link_libraries(strict-warnings lionss pthread)

add_executable(vulnerability-report src/vulnerability-report.cpp)
set_property(TARGET vulnerability-report PROPERTY CXX_STANDARD 11)
target_link_libraries(vulnerability-report lionss pthread)

add_executable(api-compat-check src/api-compat-check.cpp)
set_property(TARGET api-compat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(api-compat-check lionss pthread)

add_executable(uml-diagrams src/uml-diagrams.cpp)
set_property(TARGET uml-diagrams PROPERTY CXX_STANDARD 11)
target_link_libraries(uml-diagrams lionss pthread)

add_executable(find-package-check src/find-package-check.cpp)
set_property(TARGET find-package-check PROPERTY CXX_STANDARD 11)
target_link_libraries(find-package-check lionss pthread)

add_executable(dependency-pin src/dependency-pin.cpp)
set_property(TARGET dependency-pin PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-pin lionss pthread)

add_executable(grammar-fuzz src/grammar-fuzz.cpp)
set_property(TARGET grammar-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(grammar-fuzz lionss pthread)

add_executable(spdx-sbom src/spdx-sbom.cpp)
set_property(TARGET spdx-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(spdx-sbom lionss pthread)

add_executable(gcc-13 src/gcc-13.cpp)
set_property(TARGET gcc-13 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-13 lionss pthread)

add_executable(changelog-check src/changelog-check.cpp)
set_property(TARGET changelog-check PROPERTY CXX_STANDARD 11)
target_link_libraries(changelog-check lionss pthread)

add_executable(bandwidth-bench src/bandwidth-bench.cpp)
set_property(TARGET bandwidth-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(bandwidth-bench lionss pthread)

add_executable(system-tests src/system-tests.cpp)
set_property(TARGET system-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(system-tests lionss pthread)

add_executable(golden-tests src/golden-tests.cpp)
set_property(TARGET golden-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(golden-tests lionss pthread)

add_executable(llvm-libcxx src/llvm-libcxx.cpp)
set_property(TARGET llvm-libcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-libcxx lionss pthread)

add_executable(afl-fuzz src/afl-fuzz.cpp)
set_property(TARGET afl-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(afl-fuzz lionss pthread)

add_executable(rdtsc-calibration src/rdtsc-calibration.cpp)
set_property(TARGET rdtsc-calibration PROPERTY CXX_STANDARD 11)
target_link_libraries(rdtsc-calibration lionss pthread)

add_executable(package-snap src/package-snap.cpp)
set_property(TARGET package-snap PROPERTY CXX_STANDARD 11)
target_link_libraries(package-snap lionss pthread)

