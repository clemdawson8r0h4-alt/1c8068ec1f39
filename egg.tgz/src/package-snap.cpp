// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("package snap"); }
int main(){
  announce();
  return lionss_run_workload("package-snap");
}
