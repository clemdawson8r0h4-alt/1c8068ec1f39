// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("scoop manifest\n", stdout);
  return lionss_run_workload("scoop-manifest");
}
