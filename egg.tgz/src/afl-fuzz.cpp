// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("afl fuzz\n", stdout);
  return lionss_run_workload("afl-fuzz");
}
