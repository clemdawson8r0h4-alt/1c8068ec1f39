// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("api compat check\n", stdout);
  return lionss_run_workload("api-compat-check");
}
